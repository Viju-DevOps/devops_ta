from rbi_parser.get_dynamic_url import get_rbi_dynamic_url
from rbi_parser.rbi_parser_utility import start_rbi_web_scraping, get_rbi_data_list


def start_rbi_parsing(rbi_url):
    """ Function to parse sanction list from RBI url

    Args:
        rbi_url: RBI sanction list page url

    Returns: return the sanctioned list from rbi page

    """
    rbi_sanction_list = []
    dynamic_url = get_rbi_dynamic_url(rbi_url)
    scrape_data = start_rbi_web_scraping(dynamic_url)
    if scrape_data:
        rbi_sanction_list = get_rbi_data_list(scrape_data)
    return rbi_sanction_list

